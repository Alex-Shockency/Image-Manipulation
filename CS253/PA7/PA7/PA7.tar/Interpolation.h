#ifndef Interpolation_H_INCLUDE
#define Interpolation_H_INCLUDE
#include <Morph.h>
class Interpolation
{
public:
	//Methods
	bool Interpolate(Mapping& map1,Morph& mor,Image& img1,Image& img2);
	//Accesors
	//Mutators
private:
}
;
#endif // Morph_H_INCLUDE
